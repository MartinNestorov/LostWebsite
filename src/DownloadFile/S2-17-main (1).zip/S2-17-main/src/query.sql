select date_played, p.id, name, max(points) as maxscore, game_id  from players p
                                                                     join player_round pr on p.id = pr.player_id
                                                                     join rounds r on pr.round_id = r.id
                                                                     join games g on p.id = g.winner
group by p.id, name, game_id, date_played
order by maxscore desc;

