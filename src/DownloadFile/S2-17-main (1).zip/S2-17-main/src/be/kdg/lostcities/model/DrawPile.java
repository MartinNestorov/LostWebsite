package be.kdg.lostcities.model;

import java.util.Collections;
import java.util.Stack;

public class DrawPile extends Deck{

    public DrawPile() {
        super(new Stack<Card>());
        initializeDrawPile();
    }

    @Override
    public void putCard(Card card) {
    }

    public void shuffle(){
        Collections.shuffle(this.getDeck());
    }

    /**
     * Initializes the draw pile with a standard set of cards.
     * The draw pile is cleared, and then 10 cards of each color are added with values from 2 to 10,
     * as well as 3 wager cards with a value of 1 for each color.
     * The resulting deck is then shuffled.
     */
    public void initializeDrawPile(){
        this.getDeck().clear(); // Clear the draw pile
        for (Color color: Color.values()) { // Iterate through all Color values
            for (int i = 2; i <= 10; i++) { // Add cards with values from 2 to 10 for the current color
                getDeck().push(new Card(i, color));
            }
            for (int i = 0; i < 3; i++) { // Add 3 "wager" cards with a value of 1 for the current color
                getDeck().push(new Card(1, color));
            }
        }
        shuffle(); // Shuffle the resulting deck
    }


    public int getCount() {
        return getDeck().size();
    }
}
