package be.kdg.lostcities.model;

import java.util.ArrayList;
import java.util.Stack;

public class Board {

    private ArrayList<DiscardPile> discardPiles = new ArrayList<>(){{
        add(new DiscardPile(new Stack<Card>(), Color.RED));
        add(new DiscardPile(new Stack<Card>(), Color.BLUE));
        add(new DiscardPile(new Stack<Card>(), Color.GREEN));
        add(new DiscardPile(new Stack<Card>(), Color.YELLOW));
        add(new DiscardPile(new Stack<Card>(), Color.WHITE));
    }};

    private DrawPile drawPile = new DrawPile();

    public ArrayList<DiscardPile> getDiscardPiles() {
        return discardPiles;
    }

    @Override
    public String toString() {
        String result = "";
        for (DiscardPile dp:discardPiles) {
            result += dp.getColor() + " " + dp.getDeck() + "\n";
        }
        return result;
    }

    /**
     * Places a given card on top of all discard piles.
     * Whether or not the card belongs to that discard pile is checked withing the putCard() function
     * @param card The card to place in the discard piles.
     * @return None
     */
    public void putCardInDiscardPile(Card card){
        for (DiscardPile dp:discardPiles) {
            dp.putCard(card);
        }
    }

    /**
     * Checks if the game is over by determining if the draw pile is empty.
     *
     * @param None
     * @return True if the draw pile is empty, indicating that the game is over. False otherwise.
     */
    public boolean gameOver() {
        return drawPile.getDeck().isEmpty();
    }

    public DrawPile getDrawPile() {
        return drawPile;
    }
}
