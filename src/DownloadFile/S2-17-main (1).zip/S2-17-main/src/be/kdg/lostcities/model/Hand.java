package be.kdg.lostcities.model;

import java.util.ArrayList;

/**
 * An ArrayList that contains the cards that a player has.
 */
public class Hand {

    private ArrayList<Card> hand = new ArrayList<>();

    public Hand(ArrayList<Card> hand) {
        this.hand = hand;
    }

    public Hand(){   }

    public ArrayList<Card> getCards() {
        return hand;
    }

    @Override
    public String toString() {
        return hand.toString();
    }
}
