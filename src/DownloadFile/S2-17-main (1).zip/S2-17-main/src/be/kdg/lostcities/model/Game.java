package be.kdg.lostcities.model;

import java.util.ArrayList;

public class Game {

    private Leaderboard leaderboard;
    private Board board;
    private int round;
    private Human player_human;
    private AI player_AI;
    private Player currentPlayer;
    private Player winner;
    private long startTime;
    private long endTime;
    private long gameID;


    public Game() {
        leaderboard = new Leaderboard();
        board = new Board();
        round = 0;
        player_human = new Human(board);
        player_AI = new AI(board);
        currentPlayer = player_human;
        gameID = System.currentTimeMillis();
    }

    public void play(){
        leaderboard.addPlayer(player_human);
        player_human.setId();
        leaderboard.addPlayer(player_AI);
        player_AI.setId();

        //Deal cards
        dealCards(player_human);
        dealCards(player_AI);

        startTime = System.currentTimeMillis();

    }

    /**
     * Deals 8 cards to the specified player from the draw pile on the game board.
     * The function gets a card from the draw pile and adds it to the player's hand, and repeats this process 8 times.
     *
     * @param player the player to deal cards to
     */
    private void dealCards(Player player) {
        for (int i = 0; i < 8; i++) { // Deal 8 cards
            Card card = board.getDrawPile().getCard(); // Get a card from the draw pile
            player.getCard(card); // Add the card to the player's hand
        }
    }

    public boolean isFinished(){
        return board.gameOver();
    }

    public Board getBoard() {
        return board;
    }

    public int getRound() {
        return round;
    }

    public Leaderboard getLeaderboard() {
        return leaderboard;
    }

    public Human getPlayer_human() {
        return player_human;
    }

    public AI getPlayer_AI() {
        return player_AI;
    }

    public Player getCurrentPlayer() {
        return currentPlayer;
    }

    public long getStartTime() {
        return startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public long getElapsedTime(){
        return endTime - startTime;
    }

    public long getGameID() {
        return gameID;
    }

    public Player getWinner() {
        int humanScore = getPlayer_human().getScore();
        int aiScore = getPlayer_AI().getScore();

        if (humanScore >= aiScore) {
            this.winner = getPlayer_human();
        }else{
            this.winner = getPlayer_AI();
        }
        return this.winner;
    }


}
