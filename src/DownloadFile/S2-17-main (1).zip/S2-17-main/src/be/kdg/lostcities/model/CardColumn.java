package be.kdg.lostcities.model;

import java.util.Iterator;
import java.util.Stack;

public class CardColumn extends Deck {

    private final int EXPEDITION_COST = -20;
    private int discoveryPoints = 0;
    private Color color;

    public CardColumn(Stack<Card> deck, Color color) {
        super(deck);
        this.color = color;
    }

    /**
     * Places a given card on top of the pile if it meets certain conditions.
     *
     * @param card The card to place on top of the pile.
     *
     * @return None
     */
    @Override
    public void putCard(Card card) {
        // Check if the card matches the color of the pile
        if (card.getColor() == this.color) {
            // Check if the pile is empty, if so, place the card on top
            if (this.getDeck().empty()) {
                this.getDeck().push(card);
            } else {
                // Check if the top card has a value of 1, if so, place the card on top
                if (this.getDeck().peek().getValue() == 1) {
                    this.getDeck().push(card);
                } else {
                    // Check if the card has a greater value than the top card, if so, place the card on top
                    if (card.getValue() > this.getDeck().peek().getValue()) this.getDeck().push(card);
                }
            }
        }
    }

    /**
     * Calculates the number of points that the player earns for the expedition.
     *
     * @param None
     *
     * @return The number of points earned for the expedition.
     */
    public int calculatePoints() {
        // If the pile is empty, return 0 points
        if (this.getDeck().empty()) {
            return 0;
        }

        // Initialize variables
        int result = 0;
        int wagerCards = 0;
        int count = 0;

        // Iterate through each card in the pile
        for (Card card : this.getDeck()) {
            count += 1;
            int val = card.getValue();
            // If the value of the card is 1, increment the number of wager cards
            if (val == 1) {
                wagerCards++;
            } else {
                // Otherwise, add the card's value to the total result
                result += val;
            }
        }

        // Set the discovery points equal to the result
        discoveryPoints = result;

        // Add the expedition cost to the result
        result += EXPEDITION_COST;

        // Multiply the result by a factor based on the number of wager cards
        switch (wagerCards) {
            case 0:
            case 1:
                result *= 2;
                break;
            case 2:
                result *= 3;
                break;
            case 3:
                result *= 4;
                break;
        }

        // Return the total number of points earned for the expedition
        return result;
    }

    public Color getColor() {
        return color;
    }

    @Override
    public String toString() {
        return getDeck().toString();
    }
}
