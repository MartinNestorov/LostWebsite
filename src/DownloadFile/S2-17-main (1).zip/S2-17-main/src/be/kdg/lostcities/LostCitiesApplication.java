package be.kdg.lostcities;

import be.kdg.lostcities.view.main.MainPresenter;
import be.kdg.lostcities.view.main.MainView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import be.kdg.lostcities.model.*;

public class LostCitiesApplication extends Application {
    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage stage) throws Exception {
        final Game model = new Game();
        final MainView view = new MainView();
        final MainPresenter presenter = new MainPresenter(model, view);
        final Scene scene = new Scene(view);
        stage.setScene(scene);
        stage.setMaximized(true);
        stage.setTitle("Lost Cities");
        stage.getIcons().add(new Image("/icon.png"));
        presenter.addWindowEventHandlers();
        stage.show();
    }

}