package be.kdg.lostcities.model;

import java.sql.*;

public class Leaderboard {

    private Connection connection;
    private static Statement statement;
    private ResultSet resultSet;

    private String url = "jdbc:postgresql://10.134.178.17:5432/game";
    private String username = "game";
    private String password = "7sur7";

    public Leaderboard() {

        try {
            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }


    public void addPlayer(Player player){
        try {
            statement.executeUpdate(String.format("INSERT INTO players (name, id) VALUES ('%s', nextval('player_id_sequence'))", player.getName()));
        } catch (SQLException e){
            e.printStackTrace();
        }
    }

    public void addRound(Game game, Player player){
        long gameID = game.getGameID();
        long id = System.currentTimeMillis();
        int movesMade = player.getMovesMade();
        try {
            statement.executeUpdate(String.format("INSERT INTO rounds (game_id, round_number, id) VALUES ('%s','%s', nextval('round_id_seq'))", gameID, movesMade));
        } catch(SQLException e){
            e.printStackTrace();
        }
    }

    public static int getPlayerID(String player_name){
        try {
            String query = String.format("SELECT id FROM players WHERE name = '%s'", player_name);
            ResultSet resultSet1 = statement.executeQuery(query);

            if (resultSet1.next()) {
                int id = resultSet1.getInt("id");
                return id;
            }else{
                System.out.printf("User %s not found.\n", player_name);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return 0;
    }

    public void saveMove(Game game, Player player) {
        long gameID = game.getGameID();
        String playerName = player.getName();
        int movesMade = player.getMovesMade();
        int score = player.getScore();
        long timestamp = System.currentTimeMillis();

        try {
            statement.executeUpdate(String.format("INSERT INTO player_round(round_id, player_id, points, move_number, move_timestamp) VALUES (currval('round_id_seq'), '%d', '%s', '%s', '%s')",
                     getPlayerID(playerName), score, movesMade, timestamp));

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void addGame(Game game, Player player) {
        int winner = game.getWinner().getId();
        try{
            statement.executeUpdate(String.format("INSERT INTO games(date_played, winner, id) VALUES (CURRENT_DATE, '%s', currval('round_id_seq'))", winner));
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
    public ResultSet getHighScores(){

        String query = "select date_played, name, max(points) as maxscore, game_id  from players p\n" +
                "join player_round pr on p.id = pr.player_id\n" +
                "join rounds r on pr.round_id = r.id\n" +
                "join games g on p.id = g.winner\n" +
                "group by name, game_id, date_played\n" +
                "order by maxscore desc";

        try{
            return statement.executeQuery(query);
        } catch (SQLException e){
            e.printStackTrace();
        }


        return null;
    }



}
