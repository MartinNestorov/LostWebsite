package be.kdg.lostcities.model;

import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public class AI extends Player {

    private Map<Color, ArrayList<Integer>> sortedHand;
    public AI(Board board) {
        super(board);
        this.sortedHand = new HashMap<>() {{
            put(Color.RED, new ArrayList<>());
            put(Color.BLUE, new ArrayList<>());
            put(Color.GREEN, new ArrayList<>());
            put(Color.YELLOW, new ArrayList<>());
            put(Color.WHITE, new ArrayList<>());
        }};

        this.setName("AI");

    }

    private void sortHand() {
        for (Card card : getHand().getCards()) {
            sortedHand.get(card.getColor()).add(card.getValue());
        }
    }


    public Map<Color, ArrayList<Integer>> getSortedHand() {
        sortHand();
        return sortedHand;
    }

    /*
                   FROM NOW ON STARTS TEST PART OF THIS CLASS
    */

    // Checks sorted hand to find color with the highest number of cards
    private Color getCommonColor() {
        AtomicReference<Color> mostCommon = new AtomicReference<>(Color.RED); // to avoid nullPointerException we use RED as default
        AtomicInteger numberOfCards = new AtomicInteger();


        getSortedHand().forEach((key, value) -> {
            if (value.size() > numberOfCards.get()) {
                numberOfCards.set(value.size());
                mostCommon.set(key);
            }
        });

        return mostCommon.get();
    }

    // Returns the lowest card of given color
    private Card getLowestCard(Color mostCommonColor, ArrayList<Card> cards) {
        // Color mostCommonColor = getCommonColor(); // -> should be used in place where method called. Like: getLowestCard(getCommonColor())
//         ArrayList<Card> cards = getHand().getCards();
        Card lowestCard = null;

        for (Card currentCard : cards) {
            if (currentCard.getColor().equals(mostCommonColor) && currentCard.getValue() > 1) {
//                if (lowestCard == null && currentCard.getValue() > 1) {
//                    lowestCard = currentCard;
//                    continue;
//                }
                System.out.println("lowestl: " + lowestCard + "current: " + currentCard);
                try {
                    if (lowestCard == null) {
                        lowestCard = currentCard;
                        System.out.println("lowest is null, so it becomes :" + currentCard);
                    }
//                    else if (lowestCard.getValue() == 1) {
//                        lowestCard = currentCard;
//                    }
                    else if (currentCard.getValue() < lowestCard.getValue() && currentCard.getValue() > 1) {
                        lowestCard = currentCard;
                        System.out.println("lowest is " + lowestCard);
                    }
                } catch (NullPointerException e) {
                    System.out.println("lowest card of color " + mostCommonColor +" is null!");
                    return null;
//                    lowestCard = currentCard;

                    // TODO: it's better to discard in case of null pointer exception WRONG!!!
//                    Card discardCard = findUnplayableCards(getColumns()).get(0);
//                    if (discardCard != null) {
//                        lowestCard = discardCard;
//                    }
                }

            }
        }

        return lowestCard;
    }

    // Checks whether there are multipliers of exact color
    private Boolean checkForMultiplier(Color color) {
        ArrayList<Card> cards = getHand().getCards();

        for (Card currentCard : cards) {
            if (currentCard.getValue() == 1 && currentCard.getColor().equals(color)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Return the colors of the card columns which have cards placed in them.
     */
    private ArrayList<Color> getOpenedColumns() {
        ArrayList<Color> openedColumns = new ArrayList<>();
        for (CardColumn cc: this.getColumns()) {
            if (!cc.getDeck().isEmpty()) {
                openedColumns.add(cc.getColor());
            }
        }
        return openedColumns;
    }

    // Returns multiplier of exact color
    private Card getMultiplier(Color color) {
        for (Card currentCard : getHand().getCards()) {
            if (currentCard.getValue() == 1 && currentCard.getColor().equals(color)) {
                return currentCard;
            }
        }
        return null; // method should be called after checkForMultiplier() call
    }

    private int findIndexOfCard(Card card) {
        ArrayList<Card> hand = getHand().getCards();
        for (int i = 0; i < hand.size(); i++) {
            if (card.getValue() == hand.get(i).getValue() && card.getColor().equals(hand.get(i).getColor())){
                return i;
            }
        }
        return -1;
    }

    /*
            findUnplayableCards and getCardsFromTop could be used as logic for discarding card from hand
            based on only AIs hand, also could be used for comparing with Human columns
     */

    // Looks for unplayable cards in hand
    private ArrayList<Card> findUnplayableCards(ArrayList<CardColumn> columns) {
        ArrayList<Card> topCards = getCardsFromTop(columns);
        ArrayList<Card> unplayableCards = new ArrayList<>();

        for (Card cardInHand : getHand().getCards()) {
            // how to compare every element of topcards and hand cards!
            for (Card cardOnTable : topCards) {
                if (cardOnTable.getColor().equals(cardInHand.getColor())) {
                    if (cardOnTable.getValue() >= cardInHand.getValue()) {
                        unplayableCards.add(cardInHand);
                    }
                }
            }
        }

        // TODO: Check for debug, delete after
        System.out.println(unplayableCards);

        return unplayableCards;
    }

    private ArrayList<Card> getCardsFromTop(ArrayList<CardColumn> columns) {
        ArrayList<Card> topCards = new ArrayList<>();

        for (CardColumn column : columns) {
            if (!column.getDeck().isEmpty()) {
                topCards.add(column.getDeck().peek());
            }
        }

        return topCards;
    }

    /*
    TODO: make a method for checking whether table is empty and then perform firstMove() !
     */

    /*
                This part includes combinations of methods, moves, and general AI logic
     */


    /**
     * Get most frequent color in hand
     * Get the card with the lowest value of that color, that is NOT a multiplier card (value = 1)
     * If there's a multiplier of that color:
     *      Check if the value of the selected card is < 5
     *      If so: return multiplier
     *      Else: return selected card
     *
     */
    private Card firstMove() {
        Color commonColor = getCommonColor();
        System.out.println("Hand on first move: " + getHand());
        Card lowestCardInColumn = getLowestCard(commonColor, getHand().getCards());
        System.out.println("Lowest card on first move is: " + lowestCardInColumn);

        if (checkForMultiplier(commonColor)) {
            if (lowestCardInColumn.getValue() < 5) { // I'm not sure about it  ->TO DISCUSS<-
                return getMultiplier(commonColor);
            }
        }
        return lowestCardInColumn;
    }


    public void makeMove(){
        if(getMovesMade() == 0) {
            Card card = firstMove();
            System.out.println("first move");
            System.out.println(card);
            System.out.println("Hand for first move" + getHand());
            putCardInColumn(findIndexOfCard(card));
        } else {
            ArrayList<Card> playableCards = getPlayableCards();
            System.out.println("Regular move");
            System.out.println("Hand: " + getHand());
            System.out.println("Playable cards: " + playableCards);
            Card maxCard = getLowestCard(getCommonColor(), playableCards);
            System.out.println("Max card: " + maxCard);
            if (playableCards.size() == 0) {
                System.out.println("No playable cards, we want to discard");
//                Card maxCard = getLowestCard(getCommonColor());
//                System.out.println("Max card: " + maxCard);
                /*
                delete if else statement if not working and uncomment this section
                putCardInDiscardPile(findIndexOfCard(maxCard), this.getBoard());
                 */
                if (maxCard == null) {
                    Card discardCard = findUnplayableCards(getColumns()).get(0);
                    System.out.println("there are no playable cards and maxs is null" + discardCard);
                    putCardInDiscardPile(findIndexOfCard(discardCard), this.getBoard());
                } else {
                    putCardInDiscardPile(findIndexOfCard(maxCard), this.getBoard());
                }
            } else {
                //  1) wrong, now is taking random card from all playable, should change to lowest
//                Card card = playableCards.get((int)(Math.random() * playableCards.size()));
                System.out.println("There is playable card: " + maxCard);
                if (maxCard == null) {
                    System.out.println("We want to discard cuz max is null");
                    ArrayList<Card> discardCards = findUnplayableCards(getColumns());
                    if (discardCards.isEmpty()) {
                        putCardInDiscardPile(findIndexOfCard(playableCards.get(0)), this.getBoard());
                    } else {
                        System.out.println("max is null" + discardCards.get(0));
                        putCardInDiscardPile(findIndexOfCard(discardCards.get(0)), this.getBoard());
                    }
//                    Card discardCard = findUnplayableCards(getColumns()).get(0);
//                    System.out.println("max is null" + discardCard);
//                    putCardInDiscardPile(findIndexOfCard(discardCard), this.getBoard());
                } else {
                    if (playableCards.contains(maxCard)) {
                        System.out.println("It is in playable cards!");
                        putCardInColumn(findIndexOfCard(maxCard));
                    } else {
                        System.out.println("It's not in playable cards! Discarded");
                        putCardInDiscardPile(findIndexOfCard(maxCard), this.getBoard());
                    }
                }
            }
        }
    }

    public ArrayList<Card> getPlayableCards() {
        ArrayList<Card> playableCards = new ArrayList<>();

        for (Card card: getHand().getCards()) {
            for (CardColumn cc: getColumns()) {
                if (card.getColor().equals(cc.getColor())) {
                    if (cc.getDeck().isEmpty() || cc.getDeck().peek().getValue() < card.getValue()) {
                        playableCards.add(card);
                    }
                }

                }
            }
        return playableCards;
    }


    public int getIndexOfUnplayableCard(){
        return findIndexOfCard(getLowestCard(getCommonColor(), getHand().getCards()));
    }


}
