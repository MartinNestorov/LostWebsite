package be.kdg.lostcities.model;

import javafx.scene.Node;


public class Card extends Node {

    private int value;
    private Color color;

    public Card(int value, Color color) {
        if (1 <= value && value <= 10) {
            this.value = value;
        } else{
            return;
        }
        this.color = color;
    }

    public int getValue() {
        return value;
    }

    public Color getColor() {
        return color;
    }


    @Override
    public String toString() {
        return String.format("[%s, %d]", getColor(), value);
    }
}
