package be.kdg.lostcities.view.newgame;

import be.kdg.lostcities.model.Game;
import be.kdg.lostcities.view.game.GamePresenter;
import be.kdg.lostcities.view.game.GameView;
import be.kdg.lostcities.view.main.MainPresenter;
import be.kdg.lostcities.view.main.MainView;

public class NewGamePresenter {

    private Game model;
    private NewGameView view;

    public NewGamePresenter(Game model, NewGameView view) {
        this.model = model;
        this.view = view;

        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getStartGame().setOnAction(e -> {
            String username = view.getUsername().getText();
            model.getPlayer_human().setName(username);
            view.getUsername().setText(username);
            startGame();
        });

        view.getBack().setOnAction(e -> {
            MainView mainView = new MainView();
            MainPresenter mainPresenter = new MainPresenter(model, mainView);
            view.getScene().setRoot(mainView);
        });

    }

    private void startGame() {
        model.play();
        GameView gameView = new GameView();
        GamePresenter gamePresenter = new GamePresenter(model, gameView);
        view.getScene().setRoot(gameView);
    }

    private void updateView() {
    }
}
