package be.kdg.lostcities.view.main;

import be.kdg.lostcities.model.Game;
import be.kdg.lostcities.view.about.AboutPresenter;
import be.kdg.lostcities.view.about.AboutView;
import be.kdg.lostcities.view.game.GamePresenter;
import be.kdg.lostcities.view.game.GameView;
import be.kdg.lostcities.view.instructions.InstructionsPresenter;
import be.kdg.lostcities.view.instructions.InstructionsView;
import be.kdg.lostcities.view.leaderboards.LeaderboardsPresenter;
import be.kdg.lostcities.view.leaderboards.LeaderboardsView;
import be.kdg.lostcities.view.newgame.NewGamePresenter;
import be.kdg.lostcities.view.newgame.NewGameView;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.WindowEvent;

public class MainPresenter {
    private Game model;
    private MainView view;

    public MainPresenter(Game model, MainView view) {
        this.model = model;
        this.view = view;

        addEventHandlers();
    }

    private void addEventHandlers() {
        view.getNewGame().setOnAction(e -> {
            //TODO change scene
            startGame();
        });

        view.getInstructions().setOnAction(e -> {
            InstructionsView instructionsView = new InstructionsView();
            InstructionsPresenter instructionsPresenter = new InstructionsPresenter(model, instructionsView);
            view.getScene().setRoot(instructionsView);

        });
        view.getExitGame().setOnAction(e -> {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setHeaderText("Are you sure you want to quit the game?");
            alert.setTitle("Exit Game");
            alert.getButtonTypes().clear();
            ButtonType yes = new ButtonType("Yes");
            ButtonType no = new ButtonType("No");
            alert.getButtonTypes().addAll(yes,no);
            alert.showAndWait();
            if (alert.getResult() == null || alert.getResult().equals(no)) {
                alert.close();
            }else{
                view.getScene().getWindow().hide();
            }
        });

        view.getAbout().setOnAction(e -> {
            AboutView aboutView = new AboutView();
            AboutPresenter aboutPresenter = new AboutPresenter(model, aboutView);
            view.getScene().setRoot(aboutView);
        });

        view.getLeaderboards().setOnAction(e -> {
            LeaderboardsView leaderboardsView = new LeaderboardsView();
            LeaderboardsPresenter leaderboardsPresenter = new LeaderboardsPresenter(model, leaderboardsView);
            view.getScene().setRoot(leaderboardsView);
        });

    }

    public void addWindowEventHandlers(){
        view.getScene().getWindow().setOnCloseRequest(e -> {
            closeApplication(e);
        });
    }

    private void startGame() {
        NewGameView newGameView = new NewGameView();
        NewGamePresenter newGamePresenter = new NewGamePresenter(model, newGameView);
        view.getScene().setRoot(newGameView);
    }

    private void closeApplication(WindowEvent event) {
        //TODO alert window
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setHeaderText("Are you sure you want to quit the game?");
        alert.setTitle("Exit Game");
        alert.getButtonTypes().clear();
        ButtonType yes = new ButtonType("Yes");
        ButtonType no = new ButtonType("No");
        alert.getButtonTypes().addAll(yes,no);
        alert.showAndWait();
        if (alert.getResult() == null || alert.getResult().equals(no)) {
            event.consume();
        }
    }

    private void updateView(){

    }

}
