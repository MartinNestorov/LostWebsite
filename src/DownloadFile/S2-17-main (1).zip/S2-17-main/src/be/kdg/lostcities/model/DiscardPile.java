package be.kdg.lostcities.model;

import java.util.Stack;

public class DiscardPile extends Deck {

    private Color color;

    public DiscardPile(Stack<Card> deck, Color color) {
        super(deck);
        this.color = color;
    }

    @Override
    public void putCard(Card card) {
        if (card.getColor() == this.color){
            getDeck().push(card);
        }
    }

    public Card getCard(){
        return getDeck().pop();

    }

    public Color getColor() {
        return color;
    }
}
