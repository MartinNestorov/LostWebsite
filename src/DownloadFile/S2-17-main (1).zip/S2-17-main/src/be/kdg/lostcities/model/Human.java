package be.kdg.lostcities.model;

public class Human extends Player{

    public Human(Board board) {
        super(board);
    }

}
