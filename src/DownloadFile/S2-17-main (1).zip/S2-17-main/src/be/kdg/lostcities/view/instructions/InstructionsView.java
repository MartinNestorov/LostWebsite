package be.kdg.lostcities.view.instructions;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;

public class InstructionsView extends VBox {
    Image backgroundImage;
    BackgroundSize backgroundSize;
    BackgroundImage backgroundImg;
    Background background;
    private Label text;
    private Button back;
    private String instructions = "Both players’ goal is to form expedition routes that —\n" +
            "after subtracting the expedition costs — earn them as\n" +
            "many discovery points as possible. You set up the\n" +
            "expeditions by forming a separate column of cards for\n" +
            "each color. The numeric values within a column of\n" +
            "cards must increase from card to card. You can place\n" +
            "wager cards at the beginning of each column to\n" +
            "multiply a column’s value. At the end of the game, the\n" +
            "cards in each player’s columns are scored. \n" +
            "During your turn, you must first place one of the\n" +
            "cards from your hand. Only afterward are you allowed\n" +
            "to draw a new card.";
    public InstructionsView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        text = new Label(instructions);
        text.setStyle("-fx-background-color: AntiqueWhite;" +  "-fx-border-color: BurlyWood;" + "-fx-border-width: 6px");

        back = new Button("Back");

        backgroundImage = new Image("/peakpx.jpg");
        backgroundSize = new BackgroundSize(100, 100, true, true, true, false);
        backgroundImg = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, backgroundSize);
        background = new Background(backgroundImg);
        setBackground(background);
    }

    private void layoutNodes() {
        setAlignment(Pos.CENTER);
        text.setMaxWidth(300);
        text.setAlignment(Pos.CENTER);
        back.setAlignment(Pos.CENTER);
        getChildren().addAll(text, back);
        setMargin(text, new Insets(10));
    }

    public Button getBack() {
        return back;
    }
}
