package be.kdg.lostcities.view.about;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

public class AboutView extends VBox{

    private Image logo_image;
    private ImageView imageView;
    Image backgroundImage;
    BackgroundSize backgroundSize;
    BackgroundImage backgroundImg;
    Background background;
    private Label text;
    private Button back;
    private String instructions = "We are TEAM 17!\n Members:\nOleksii Demydenko\nSamuel Glecer\nMartin Nestorov\nHilmi Yetgin";

    public AboutView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        backgroundImage = new Image("/peakpx.jpg");
        backgroundSize = new BackgroundSize(100, 100, true, true, true, false);
        backgroundImg = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, backgroundSize);
        background = new Background(backgroundImg);
        setBackground(background);

        text = new Label(instructions);
        text.setStyle("-fx-background-color: AntiqueWhite;" +  "-fx-border-color: BurlyWood;" + "-fx-border-width: 6px;" + "-fx-text-alignment: center");

        back = new Button("Back");
    }

    private void layoutNodes() {
        setAlignment(Pos.CENTER);
        text.setMaxWidth(300);
        text.setAlignment(Pos.CENTER);
        back.setAlignment(Pos.CENTER);
        getChildren().addAll(text, back);
        setMargin(text, new Insets(10));

    }

    public Button getBack() {
        return back;
    }
}
