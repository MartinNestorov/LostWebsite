package be.kdg.lostcities.view.leaderboards;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.*;

public class LeaderboardsView extends VBox{
    private Image backgroundImage;
    private BackgroundSize backgroundSize;
    private BackgroundImage backgroundImg;
    private Background background;
    private Button back;

    public LeaderboardsView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        back = new Button("Back");

        backgroundImage = new Image("/peakpx.jpg");
        backgroundSize = new BackgroundSize(100, 100, true, true, true, false);
        backgroundImg = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, backgroundSize);
        background = new Background(backgroundImg);
        setBackground(background);
    }

    private void layoutNodes() {
        setAlignment(Pos.CENTER);
        back.setAlignment(Pos.CENTER);
        getChildren().addAll(back);

    }

    public Button getBack() {
        return back;
    }
}
