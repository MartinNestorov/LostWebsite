package be.kdg.lostcities.view.game;

import be.kdg.lostcities.model.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.ArrayList;
import java.util.Stack;

public class GameView extends BorderPane {

    private final int CARD_WIDTH = 40;
    private final int CARD_HEIGHT = 40;
    private final int CARD_MARGIN = 19;
    private final int TOP_MARGIN = CARD_MARGIN / 2;
    private final int BOARD_WIDTH = 5 * CARD_WIDTH + 6 * CARD_MARGIN;
    private final int BOARD_HEIGHT = CARD_HEIGHT + 2 * TOP_MARGIN;
    private final int HAND_WIDTH = 8 * CARD_WIDTH + 9 * CARD_MARGIN;
    private final int HAND_HEIGHT = BOARD_HEIGHT;
    private final int MAX_CARDS_IN_ROW = 5;
    private final int MAX_CARDS_IN_COLUMN = 8;
    private final int TOTAL_SPACE = MAX_CARDS_IN_ROW * MAX_CARDS_IN_COLUMN * 2 + MAX_CARDS_IN_ROW;
    private final int DISCARD_PILE_ROW = 8;

    private final int RED_COL = 0;
    private final int BLUE_COL = 1;
    private final int GREEN_COL = 2;
    private final int YELLOW_COL = 3;
    private final int WHITE_COL = 4;

    private final int HUMAN_ROW_START = DISCARD_PILE_ROW + 1;
    private final int AI_ROW_START = DISCARD_PILE_ROW - 1;


    private StackPane boardPane;
    private StackPane handPane;
    private GridPane board_grid;
    private HBox hand_hbox;
    private Rectangle board_rectangle;
    private Rectangle hand_rectangle;

    private ToggleGroup hand_toggleGroup;
    private ToggleGroup discardPiles_toggleGroup;
    private ToggleButton red_discardPile;
    private ToggleButton blue_discardPile;
    private ToggleButton green_discardPile;
    private ToggleButton yellow_discardPile;
    private ToggleButton white_discardPile;
    private Button drawPile;
    private TextField score;
    private Image backgroundImage;
    private BackgroundSize backgroundSize;
    private BackgroundImage backgroundImg;
    private Background background;


    public GameView() {
        initialiseNodes();
        layoutNodes();

    }

    private void initialiseNodes() {
        board_rectangle = new Rectangle(BOARD_WIDTH, BOARD_HEIGHT);
        board_rectangle.setFill(Color.BROWN);
        hand_rectangle = new Rectangle(HAND_WIDTH, HAND_HEIGHT);
        hand_rectangle.setFill(Color.BROWN);

        board_grid = new GridPane();
        board_grid.setVgap(TOP_MARGIN);
        board_grid.setHgap(CARD_MARGIN);

        drawPile = new Button();

        score = new TextField("Score: ");
        score.setStyle("-fx-background-color: transparent;" + "-fx-text-fill: white");

        hand_hbox = new HBox(CARD_MARGIN);

        boardPane = new StackPane(board_rectangle, board_grid, drawPile);
        StackPane.setMargin(drawPile, new Insets(0,0,0,CARD_WIDTH*(MAX_CARDS_IN_ROW+2) + CARD_MARGIN*(MAX_CARDS_IN_ROW)));

        handPane = new StackPane(score, hand_rectangle, hand_hbox);


        hand_toggleGroup = new ToggleGroup();
        discardPiles_toggleGroup = new ToggleGroup();

        red_discardPile = new ToggleButton();
        blue_discardPile = new ToggleButton();
        green_discardPile = new ToggleButton();
        yellow_discardPile = new ToggleButton();
        white_discardPile = new ToggleButton();

        red_discardPile.setToggleGroup(discardPiles_toggleGroup);
        blue_discardPile.setToggleGroup(discardPiles_toggleGroup);
        green_discardPile.setToggleGroup(discardPiles_toggleGroup);
        yellow_discardPile.setToggleGroup(discardPiles_toggleGroup);
        white_discardPile.setToggleGroup(discardPiles_toggleGroup);

        backgroundImage = new Image("/canvas.jpg");
        backgroundSize = new BackgroundSize(100, 100, true, true, true, false);
        backgroundImg = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, backgroundSize);
        background = new Background(backgroundImg);
        setBackground(background);

    }

    private void layoutNodes() {
        boardPane.setAlignment(Pos.CENTER);
        boardPane.setPrefWidth(CARD_WIDTH*MAX_CARDS_IN_ROW + CARD_MARGIN*(MAX_CARDS_IN_ROW+1));
        setCenter(boardPane);

        //handPane.setAlignment(Pos.CENTER);
        setBottom(handPane);

        board_grid.setAlignment(Pos.TOP_CENTER);
        hand_hbox.setAlignment(Pos.CENTER);

        drawPile.setMinHeight(CARD_HEIGHT);
        drawPile.setMinWidth(CARD_WIDTH);



    }

    void drawHand(ArrayList<Card> player_hand) {
        getHand_hbox().getChildren().clear();
        for (Card card : player_hand) {
            ToggleButton button = new ToggleButton();
            button.setToggleGroup(hand_toggleGroup);
            button.setMinHeight(CARD_HEIGHT);
            button.setMinWidth(CARD_WIDTH);
            button.setText("" + card.getValue());
            button.setStyle("-fx-background-color: " + card.getColor().getHexValue() + ";");
            getHand_hbox().getChildren().add(button);
        }

    }

    void updateDeck(int count){
        drawPile.setText("" + count);
    }

    void drawInitialBoard(Board board) {
        getBoard_grid().getChildren().clear();
        int col = 0;
        int row = 0;

        for (int i = 0; i < TOTAL_SPACE - MAX_CARDS_IN_ROW; i++) {
            if (row != DISCARD_PILE_ROW) {
                Region emptySpace = new Region();
                emptySpace.setMinHeight(CARD_HEIGHT);
                emptySpace.setMinWidth(CARD_WIDTH);
                getBoard_grid().add(emptySpace, col, row);
                col++;
            } else {
                for (DiscardPile discardPile : board.getDiscardPiles()) {
                    ToggleButton button;
                    switch (discardPile.getColor()) {
                        case RED:
                            button = red_discardPile;
                            break;
                        case BLUE:
                            button = blue_discardPile;
                            break;
                        case GREEN:
                            button = green_discardPile;
                            break;
                        case YELLOW:
                            button = yellow_discardPile;
                            break;
                        case WHITE:
                            button = white_discardPile;
                            break;
                        default:
                            return;
                    }

                    button.setMinHeight(CARD_HEIGHT);
                    button.setMinWidth(CARD_WIDTH);
                    button.setStyle("-fx-background-color: " + discardPile.getColor().getHexValue() + ";");

                    getBoard_grid().add(button, col, row);
                    GridPane.setMargin(button, new Insets(TOP_MARGIN, 0, TOP_MARGIN, 0));

                    updateDiscardPileView(discardPile);

                    col++;
                }
            }

            if (col == 5) {
                row++;
                col = 0;
            }
        }


    }

    void updateDiscardPileView(DiscardPile discardPile) {
        ToggleButton button;
        switch (discardPile.getColor()) {
            case RED:
                button = red_discardPile;
                break;
            case BLUE:
                button = blue_discardPile;
                break;
            case GREEN:
                button = green_discardPile;
                break;
            case YELLOW:
                button = yellow_discardPile;
                break;
            case WHITE:
                button = white_discardPile;
                break;
            default:
                return;
        }
        Stack<Card> deck = discardPile.getDeck();
        if (deck.isEmpty()) {
            button.setText("");
        } else {
            button.setText("" + deck.peek().getValue());
        }

    }

    void updateCardColumnView(Player player, CardColumn cardColumn) {
        if (cardColumn.getDeck().isEmpty()) {
            return;
        }
        ToggleButton button = new ToggleButton();
        button.setMinHeight(CARD_HEIGHT);
        button.setMinWidth(CARD_WIDTH);
        button.setStyle("-fx-background-color: " + cardColumn.getColor().getHexValue() + ";");
        button.setText("" + cardColumn.getDeck().peek().getValue());

        int col;
        int row;

        if (player instanceof AI) {
            row = DISCARD_PILE_ROW - cardColumn.getDeck().size();
        } else if (player instanceof Human) {
            row = DISCARD_PILE_ROW + cardColumn.getDeck().size();
        } else {
            return;
        }

        switch (cardColumn.getColor()) {
            case RED:
                col = RED_COL;
                break;
            case BLUE:
                col = BLUE_COL;
                break;
            case GREEN:
                col = GREEN_COL;
                break;
            case YELLOW:
                col = YELLOW_COL;
                break;
            case WHITE:
                col = WHITE_COL;
                break;
            default:
                col = 0;
        }

        getBoard_grid().add(button, col, row);

    }

    public StackPane getBoardPane() {
        return boardPane;
    }

    public StackPane getHandPane() {
        return handPane;
    }

    public GridPane getBoard_grid() {
        return board_grid;
    }

    public HBox getHand_hbox() {
        return hand_hbox;
    }


    public ToggleButton getRed_discardPile() {
        return red_discardPile;
    }

    public ToggleButton getBlue_discardPile() {
        return blue_discardPile;
    }

    public ToggleButton getGreen_discardPile() {
        return green_discardPile;
    }

    public ToggleButton getYellow_discardPile() {
        return yellow_discardPile;
    }

    public ToggleButton getWhite_discardPile() {
        return white_discardPile;
    }

    public Button getDrawPile(){ return drawPile; }

    public int getCARD_WIDTH() {
        return CARD_WIDTH;
    }

    public int getCARD_HEIGHT() {
        return CARD_HEIGHT;
    }

    public int getCARD_MARGIN() {
        return CARD_MARGIN;
    }

    public int getTOP_MARGIN() {
        return TOP_MARGIN;
    }

    public int getBOARD_WIDTH() {
        return BOARD_WIDTH;
    }

    public int getBOARD_HEIGHT() {
        return BOARD_HEIGHT;
    }

    public int getHAND_WIDTH() {
        return HAND_WIDTH;
    }

    public int getHAND_HEIGHT() {
        return HAND_HEIGHT;
    }

    public int getMAX_CARDS_IN_ROW() {
        return MAX_CARDS_IN_ROW;
    }

    public int getMAX_CARDS_IN_COLUMN() {
        return MAX_CARDS_IN_COLUMN;
    }

    public int getTOTAL_SPACE() {
        return TOTAL_SPACE;
    }

    public int getDISCARD_PILE_ROW() {
        return DISCARD_PILE_ROW;
    }

    public int getRED_COL() {
        return RED_COL;
    }

    public int getBLUE_COL() {
        return BLUE_COL;
    }

    public int getGREEN_COL() {
        return GREEN_COL;
    }

    public int getYELLOW_COL() {
        return YELLOW_COL;
    }

    public int getWHITE_COL() {
        return WHITE_COL;
    }

    public int getHUMAN_ROW_START() {
        return HUMAN_ROW_START;
    }

    public int getAI_ROW_START() {
        return AI_ROW_START;
    }

    public ToggleGroup getHand_toggleGroup() {
        return hand_toggleGroup;
    }

    public ToggleGroup getDiscardPiles_toggleGroup() {
        return discardPiles_toggleGroup;
    }

    public TextField getScore() {
        return score;
    }
}


