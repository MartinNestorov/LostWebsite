package be.kdg.lostcities.view.game;

import be.kdg.lostcities.model.*;
import be.kdg.lostcities.view.endgame.EndgamePresenter;
import be.kdg.lostcities.view.endgame.EndgameView;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.GridPane;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GamePresenter {
    private Game model;
    private GameView view;
    private boolean cardDropped;
    private int start;
    private int end;
    private List<Integer> red_col_idx;
    private List<Integer> blue_col_idx;
    private List<Integer> green_col_idx;
    private List<Integer> yellow_col_idx;
    private List<Integer> white_col_idx;

    public GamePresenter(Game model, GameView gameView) {
        this.model = model;
        this.view = gameView;
        this.cardDropped = false;

        view.drawInitialBoard(model.getBoard());
        updateView();
        addEventHandlers();

    }

    private void addEventHandlers() {
        addHandEventHandlers();
        addCardColumnsEventHandlers();
    }

    private void addCardColumnsEventHandlers() {
        GridPane grid = view.getBoard_grid();

        if (model.getCurrentPlayer() instanceof Human) {
            start = view.getHUMAN_ROW_START() * view.getMAX_CARDS_IN_ROW();
            end = view.getTOTAL_SPACE() - view.getMAX_CARDS_IN_ROW();

            red_col_idx = new ArrayList<>(Arrays.asList(45, 50, 55, 60, 65, 70, 75));
            blue_col_idx = new ArrayList<>(Arrays.asList(46, 51, 56, 61, 66, 71, 76));
            green_col_idx = new ArrayList<>(Arrays.asList(47, 52, 57, 62, 67, 72, 77));
            yellow_col_idx = new ArrayList<>(Arrays.asList(48, 53, 58, 63, 68, 73, 78));
            white_col_idx = new ArrayList<>(Arrays.asList(49, 54, 59, 64, 69, 74, 79));
//        } else {
//            start = view.getAI_ROW_START() * view.getMAX_CARDS_IN_ROW();
//            end = view.getMAX_CARDS_IN_COLUMN() * view.getMAX_CARDS_IN_ROW() - 1;
//
//            red_col_idx = new ArrayList<>(Arrays.asList(0, 5, 10, 15, 20, 25, 30));
//            blue_col_idx = new ArrayList<>(Arrays.asList(1, 6, 11, 16, 21, 26, 31));
//            green_col_idx = new ArrayList<>(Arrays.asList(2, 7, 12, 17, 22, 27, 32));
//            yellow_col_idx = new ArrayList<>(Arrays.asList(3, 8, 13, 18, 23, 28, 33));
//            white_col_idx = new ArrayList<>(Arrays.asList(4, 9, 14, 19, 24, 29, 34));
        }

        Color cardColor = null;
        for (int i = start; i < end; i++) {
            if (red_col_idx.contains(i)) {
                cardColor = Color.RED;
            } else if (blue_col_idx.contains(i)) {
                cardColor = Color.BLUE;
            } else if (green_col_idx.contains(i)) {
                cardColor = Color.GREEN;
            } else if (yellow_col_idx.contains(i)) {
                cardColor = Color.YELLOW;
            } else if (white_col_idx.contains(i)) {
                cardColor = Color.WHITE;
            }

            Node space = grid.getChildren().get(i);
            Color finalCardColor = cardColor;
            space.setOnMouseClicked(e -> {
                ObservableList<Node> children = view.getHand_hbox().getChildren();
                for (int j = 0; j < children.size(); j++) {
                    ToggleButton card_in_hand = (ToggleButton) children.get(j);

                    String style = card_in_hand.getStyle().split(": ")[1];
                    String color = style.split(";")[0];
                    Color cardColumnColor = Color.getColor(color);
                    if (card_in_hand.isSelected() && finalCardColor.equals(cardColumnColor)) {

                        Player currentPlayer = model.getPlayer_human();
                        for (CardColumn cc : currentPlayer.getColumns()) {
                            if (cc.getColor().equals(cardColumnColor)) {
                                currentPlayer.putCardInColumn(j);
                                currentPlayer.incrementMoves();
                                view.updateCardColumnView(currentPlayer, cc);
                                updateView();
                                addHandEventHandlers();
                                addDiscardPileEventHandlers();
                                addDrawPileEventHandler();
                                cardDropped = false;
                            }
                        }

                    }

                }
            });
        }

    }


    private void addHandEventHandlers() {
        ObservableList<Node> children = view.getHand_hbox().getChildren();
        for (int i = 0; i < children.size(); i++) {
            ToggleButton toggleButton = (ToggleButton) children.get(i);
            toggleButton.setOnAction(new HandEventHandler(i));
        }
    }


    private void takeTurn_AI() {
        if (model.getPlayer_AI().getPlayableCards().size() == 0) {
            model.getPlayer_AI().putCardInDiscardPile(model.getPlayer_AI().getIndexOfUnplayableCard(), model.getBoard());
        } else {
            model.getPlayer_AI().makeMove();
        }

        model.getPlayer_AI().incrementMoves();

        for (CardColumn cc : model.getPlayer_AI().getColumns()) {
            view.updateCardColumnView(model.getPlayer_AI(), cc);
        }

        model.getPlayer_AI().getCard(model.getBoard().getDrawPile().getCard());
        model.getLeaderboard().addRound(model, model.getPlayer_AI());
        model.getLeaderboard().saveMove(model, model.getPlayer_AI());
        checkEndGame();
    }


    private void updateView() {
        ArrayList<Card> player_hand = model.getPlayer_human().getHand().getCards();
        view.drawHand(player_hand);

        for (DiscardPile dp : model.getBoard().getDiscardPiles()) {
            view.updateDiscardPileView(dp);
        }

        view.updateDeck(model.getBoard().getDrawPile().getCount());
        model.getPlayer_human().calculateScore();
        model.getPlayer_AI().calculateScore();
        view.getScore().setText("Score: " + model.getPlayer_human().getScore());

    }

    private void checkEndGame(){
        if (model.isFinished()) {
            model.setEndTime(System.currentTimeMillis());

            model.getLeaderboard().addGame(model, model.getWinner());

            EndgameView endgameView = new EndgameView();
            EndgamePresenter endgamePresenter = new EndgamePresenter(model, endgameView);
            view.getScene().setRoot(endgameView);
        }
    }

    private void addDrawPileEventHandler() {
        view.getDrawPile().setOnAction(e -> {
            if (model.getPlayer_human().getHand().getCards().size() < 8) {
                model.getPlayer_human().getCard(model.getBoard().getDrawPile().getCard());
                model.getLeaderboard().addRound(model, model.getPlayer_human());
                model.getLeaderboard().saveMove(model, model.getPlayer_human());
                cardDropped = false;
                checkEndGame();
                takeTurn_AI();
                updateView();
                addHandEventHandlers();
            }
        });
    }

    /**
     * Iterates over each discard pile button and adds an event handler to it.
     * The handler first checks if the player has dropped a card from their hand. This is done via the cardDropped value
     * If so, this means that the player can draw a card from the discard pile
     * The color of the selected discard pile button is determined
     * Then, a card is drawn from the corresponding discard pile, and added to the player's hand
     * Finally, the view is updated, and and event handler is added to the new card in the player's hand
     */
    private void addDiscardPileEventHandlers() {
        ArrayList<ToggleButton> discardPiles = new ArrayList<>() {{
            add(view.getRed_discardPile());
            add(view.getBlue_discardPile());
            add(view.getGreen_discardPile());
            add(view.getYellow_discardPile());
            add(view.getWhite_discardPile());
        }};

        for (ToggleButton dp : discardPiles) {
            dp.setOnAction(e -> {
                if (cardDropped) {
                    String dp_style = dp.getStyle().split(": ")[1];
                    String dp_color = dp_style.split(";")[0];
                    Color dp_color_enum = Color.getColor(dp_color);
                    for (DiscardPile discardPile : model.getBoard().getDiscardPiles()) {
                        if (discardPile.getColor().equals(dp_color_enum)) {
                            if (!discardPile.getDeck().isEmpty()) {
                                model.getPlayer_human().getCard(discardPile.getCard());
                            }
                            takeTurn_AI();
                            updateView();
                            addHandEventHandlers();
                        }
                    }
                    cardDropped = false;
                }
            });
        }
    }

    private class HandEventHandler implements EventHandler<ActionEvent> {
        private int idx;

        private HandEventHandler(int idx) {
            this.idx = idx;
        }

        /**
         * @param actionEvent Triggered when the current player selects a card in their hand
         *                    When a card is selected, it's index is passed to the handler.
         *                    The handler first determines the color of the card.
         *                    Then it iterates over each discard pile and adds an event handler to it.
         *                    When a discard pile is selected, the color of the selected card and the color of the discard pile are compared
         *                    If they are the same, the selected card is removed from the hand (using its index) and is added to the corresponding discard pile.
         *                    If not, nothing happens.
         *                    After the card has been added to the discard pile, the cardDropped value becomes true (allows drawing from either discard pile or draw pile)
         *                    Finally event handlers and the view are updated.
         */
        @Override
        public void handle(ActionEvent actionEvent) {

            ToggleButton card_in_hand = (ToggleButton) actionEvent.getSource();
            String style = card_in_hand.getStyle().split(": ")[1];
            String color = style.split(";")[0];
            Color cardColor = Color.getColor(color);

            ArrayList<ToggleButton> discardPiles = new ArrayList<>() {{
                add(view.getRed_discardPile());
                add(view.getBlue_discardPile());
                add(view.getGreen_discardPile());
                add(view.getYellow_discardPile());
                add(view.getWhite_discardPile());
            }};


            for (ToggleButton dp : discardPiles) {
                dp.setOnAction(e -> {
                    String dp_style = dp.getStyle().split(": ")[1];
                    String dp_color = dp_style.split(";")[0];
                    Color dp_color_enum = Color.getColor(dp_color);

                    if (card_in_hand.isSelected() && cardColor.equals(dp_color_enum)) {
                        dp.setSelected(false);
                        card_in_hand.setSelected(false);
                        model.getPlayer_human().putCardInDiscardPile(idx, model.getBoard());
                        model.getPlayer_human().incrementMoves();
                        cardDropped = true;

                        updateView();
                        addDiscardPileEventHandlers();
                        addDrawPileEventHandler();
                    }
                });
            }

        }


    }
}







