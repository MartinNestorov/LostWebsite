package be.kdg.lostcities.view.main;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

public class MainView extends VBox {

    private Image logo_image;
    private ImageView imageView;
    private Image backgroundImage;
    private BackgroundSize backgroundSize;
    private BackgroundImage backgroundImg;
    private Background background;
    private Button newGame;
    private Button exitGame;
    private Button instructions;
    private Button about;
    private Button leaderboards;

    public MainView(){
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        logo_image = new Image("/lostcitieslogo.png");
        imageView = new ImageView(logo_image);
        newGame = new Button("New Game");
        exitGame = new Button("Exit Game");
        instructions = new Button("Instructions");
        about = new Button("About");
        leaderboards = new Button("Leaderboards");

        backgroundImage = new Image("/peakpx.jpg");
        backgroundSize = new BackgroundSize(100, 100, true, true, true, false);
        backgroundImg = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, backgroundSize);
        background = new Background(backgroundImg);
        setBackground(background);
    }

    private void layoutNodes() {
        setAlignment(Pos.CENTER);

        newGame.setPrefWidth(150);
        exitGame.setPrefWidth(150);
        instructions.setPrefWidth(150);
        about.setPrefWidth(150);
        leaderboards.setPrefWidth(150);

        getChildren().add(imageView);
        getChildren().add(newGame);
        getChildren().add(instructions);
        getChildren().add(about);
        getChildren().add(leaderboards);
        getChildren().add(exitGame);

        for (Node node:getChildren()) {
            setMargin(node, new Insets(5, 0, 5, 10));
        }

    }

    public Button getNewGame() {
        return newGame;
    }

    public Button getExitGame() {
        return exitGame;
    }

    public Button getInstructions() {
        return instructions;
    }

    public Button getAbout() {
        return about;
    }

    public Button getLeaderboards() {return leaderboards;}
}
