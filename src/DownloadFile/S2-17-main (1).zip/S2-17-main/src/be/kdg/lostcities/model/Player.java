package be.kdg.lostcities.model;

import java.util.ArrayList;
import java.util.Stack;

public class Player {
    private String name;
    private int id;
    private int score = 0;
    private int movesMade = 0;
    private Board board;
    private Hand hand = new Hand();

    public Player(Board board) {
        this.board = board;
    }

    private ArrayList<CardColumn> columns = new ArrayList<CardColumn>(){
        {
            add(new CardColumn(new Stack<Card>(), Color.RED));
            add(new CardColumn(new Stack<Card>(), Color.BLUE));
            add(new CardColumn(new Stack<Card>(), Color.YELLOW));
            add(new CardColumn(new Stack<Card>(), Color.GREEN));
            add(new CardColumn(new Stack<Card>(), Color.WHITE));
        }
    };

    public void setId() {
        this.id = Leaderboard.getPlayerID(this.name);
    }

    /**
     * Removes a card from the player's hand at the specified index.
     *
     * @param idx The index of the card to be removed.
     * @return The card that was removed from the hand.
     */
    public Card removeCard(int idx){
        return hand.getCards().remove(idx);
    }

    /**
     * Attempts to put a card from the player's hand into the specified card column. The function searches through all
     * the card columns and checks if the card's color matches the column's color, and if the card's value is greater than
     * or equal to the value of the top card in the column. If a suitable column is found, the card is added to the top
     * of the column, and removed from the player's hand.
     *
     * @param idx the index of the card in the player's hand that is being put into a column
     */
    public void putCardInColumn(int idx){
        Card card = hand.getCards().get(idx);
        Color color = card.getColor();
        int value = card.getValue();

        for (CardColumn col : columns) { // Loop through all the card columns
            if (col.getColor().equals(color) && (col.getDeck().isEmpty() || value >= col.getDeck().peek().getValue())) {
                // Check if the card's color matches the column's color and if the card's value is greater than or equal to
                // the value of the top card in the column
                col.putCard(card); // Add the card to the top of the column
                removeCard(idx); // Remove the card from the player's hand
                return; // Stop searching for a suitable column
            }
        }
    }

    /**
     * Removes a card from the player's hand at the specified index and adds it to the discard pile on the board.
     *
     * @param idx The index of the card to be removed.
     * @param board The board to add the removed card to the discard pile.
     */
    public void putCardInDiscardPile(int idx, Board board){
        Card card = removeCard(idx);
        board.putCardInDiscardPile(card);
    }

    /**
     * Calculates the player's score by summing the points of all card columns and adding additional points for columns
     * with eight or more cards.
     */
    public void calculateScore(){
        int result = 0;
        for (CardColumn col : columns) {
            result += col.calculatePoints();
        }

        for (CardColumn cc : columns) {
            if(cc.getDeck().size() >= 8){
                result += 20;
            }
        }

        this.score = result;

    }

    public void getCard(Card card){
        if (hand.getCards().size() < 8) {
            hand.getCards().add(card);
        }
    }

    public int getScore() {
        return score;
    }

    public Hand getHand() {
        return hand;
    }

    public ArrayList<CardColumn> getColumns() {
        return columns;
    }

    public int getMovesMade() {
        return movesMade;
    }

    public void incrementMoves(){
        movesMade++;
    }

    public Board getBoard() {
        return board;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Player{" +
                "score=" + score +
                ", hand=" + hand +
                ", columns=" + columns +
                '}';
    }


}
