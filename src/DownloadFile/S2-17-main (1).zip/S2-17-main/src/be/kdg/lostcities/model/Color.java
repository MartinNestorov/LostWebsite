package be.kdg.lostcities.model;

public enum Color {

    //YELLOW, GREEN, BLUE, WHITE;

    RED("#ffb3ba"),
    YELLOW("#FFFFBA"),
    GREEN("#BAFFC9"),
    BLUE("#BAE1FF"),
    WHITE("#FFFFFF");

    private final String hexValue;

    Color(String hexValue) {
        this.hexValue = hexValue;
    }

    public String getHexValue() {
        return hexValue;
    }

    /**
     * Returns the Color object corresponding to the given hex value.
     *
     * @param hexValue The hexadecimal value of the color.
     *
     * @return The Color object corresponding to the given hex value, or null if no matching color is found.
     */
    public static Color getColor(String hexValue){
        Color result = null;
        // Iterate through all Color values
        for (Color color: Color.values()) {
            // If the hex value matches the given value, return the corresponding color
            if(color.getHexValue().equals(hexValue)){
                result = color;
            }
        }
        // Return the matching color, or null if no matching color was found
        return result;
    }
}

