package be.kdg.lostcities.view.newgame;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;

public class NewGameView extends VBox {
    Image backgroundImage;
    BackgroundSize backgroundSize;
    BackgroundImage backgroundImg;
    Background background;
    private Label title;
    private Label enterUsername;
    private TextField username;
    private Button back;
    private Button startGame;
    private HBox buttons;

    public NewGameView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        title = new Label("New Game");
        enterUsername = new Label("Enter username: ");
        username = new TextField();
        back = new Button("Back");
        startGame = new Button("Start Game");
        buttons = new HBox(back, startGame);

        backgroundImage = new Image("/peakpx.jpg");
        backgroundSize = new BackgroundSize(100, 100, true, true, true, false);
        backgroundImg = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, backgroundSize);
        background = new Background(backgroundImg);
        setBackground(background);
    }

    private void layoutNodes() {
        setAlignment(Pos.CENTER);
        setMargin(username, new Insets(20));
        username.setMaxWidth(150);
        buttons.setAlignment(Pos.CENTER);
        getChildren().addAll(title, enterUsername, username, buttons);
    }

    public Label getTitle() {
        return title;
    }

    public Label getEnterUsername() {
        return enterUsername;
    }

    public TextField getUsername() {
        return username;
    }

    public Button getBack() {
        return back;
    }

    public Button getStartGame() {
        return startGame;
    }
}
