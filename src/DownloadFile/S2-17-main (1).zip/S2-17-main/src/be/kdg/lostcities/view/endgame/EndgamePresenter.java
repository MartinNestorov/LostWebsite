package be.kdg.lostcities.view.endgame;

import be.kdg.lostcities.model.Game;
import be.kdg.lostcities.view.main.MainPresenter;
import be.kdg.lostcities.view.main.MainView;

public class EndgamePresenter {
    private Game model;
    private EndgameView view;

    public EndgamePresenter(Game model, EndgameView view) {
        this.model = model;
        this.view = view;

        addEventHandlers();
        view.setWinner(model.getWinner().getName());
    }

    private void addEventHandlers() {
        view.getBack().setOnAction(e -> {
            MainView mainView = new MainView();
            MainPresenter mainPresenter = new MainPresenter(model, mainView);
            view.getScene().setRoot(mainView);
        });
    }


}
