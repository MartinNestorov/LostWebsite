package be.kdg.lostcities.model;

import java.util.Stack;
import be.kdg.lostcities.model.*;
public abstract class Deck {

    private Stack<Card> deck = new Stack<>();

    public Deck(Stack<Card> deck) {
        this.deck = deck;
    }

    public Card getCard(){
        return deck.pop();
    }

    public abstract void putCard(Card card);

    public Stack<Card> getDeck() {
        return deck;
    }

}
