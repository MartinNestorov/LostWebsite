package be.kdg.lostcities.view.about;

import be.kdg.lostcities.model.Game;
import be.kdg.lostcities.view.main.MainPresenter;
import be.kdg.lostcities.view.main.MainView;

public class AboutPresenter {
    private Game model;
    private AboutView view;

    public AboutPresenter(Game model, AboutView view) {
        this.model = model;
        this.view = view;

        addEventHandlers();
    }

    private void addEventHandlers() {
        view.getBack().setOnAction(e -> {
            MainView mainView = new MainView();
            MainPresenter mainPresenter = new MainPresenter(model, mainView);
            view.getScene().setRoot(mainView);
        });
    }
}
