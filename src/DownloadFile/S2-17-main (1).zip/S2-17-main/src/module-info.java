open module LostCities {
    requires javafx.media;
    requires javafx.controls;
    requires java.sql;
}