CREATE TABLE players
(
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL
);

CREATE TABLE games (
    id SERIAL PRIMARY KEY,
    date_played DATE NOT NULL,
    winner INT NOT NULL,
    FOREIGN KEY (winner) REFERENCES players(id)
);

CREATE TABLE rounds (
    id SERIAL PRIMARY KEY,
    game_id INT NOT NULL,
    round_number INT NOT NULL,
    FOREIGN KEY (game_id) REFERENCES games(id)
);

CREATE TABLE cards (
    id SERIAL PRIMARY KEY,
    value INT NOT NULL
);

CREATE TABLE card_round (
    card_id INT NOT NULL,
    round_id INT NOT NULL,
    PRIMARY KEY (card_id, round_id),
    FOREIGN KEY (card_id) REFERENCES cards(id),
    FOREIGN KEY (round_id) REFERENCES rounds(id)
);

CREATE TABLE player_round (
    player_id INT NOT NULL,
    round_id INT NOT NULL,
    points INT NOT NULL,
    move_number INT NOT NULL,
    move_timestamp TIMESTAMP(3) NOT NULL,
    PRIMARY KEY (player_id, round_id),
    FOREIGN KEY (player_id) REFERENCES players(id),
    FOREIGN KEY (round_id) REFERENCES rounds(id)
);

CREATE TABLE game_stats (
    id SERIAL PRIMARY KEY,
    game_id INT NOT NULL,
    average_move_duration INTERVAL NOT NULL,
    outlier_moves INTEGER[] NOT NULL,
    move_durations INTERVAL[] NOT NULL,
    most_profitable_move INT,
    FOREIGN KEY (game_id) REFERENCES games(id)
);
